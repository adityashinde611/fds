

#include <iostream>
using namespace std;
struct node{
    int roll;
    char name[10];
    node *next;
};
node *nnode, *temp, *temp1, *temp2;
class PinClub{
    node *president,*secretary;
    public:
    PinClub(){
        president=secretary=NULL;
    }
    void create();
    void addpresident();
    void addsecretary();
    void delet();
    void display();
};

void PinClub::create(){
    char ch;
    do{
        nnode = new node;
        nnode -> next = NULL;
        cout<<"\nEnter roll number ";
        cin>>nnode->roll;
        cout<<"\nEnter name ";
        cin>>nnode->name;
        if(president==NULL){
            president = secretary = nnode;
        }
        else{
            secretary->next = nnode;
            secretary=nnode;
        }
        cout<<"\nDo you want to add more members to club? y or n ";
        cin>>ch;
    }
    while(ch=='y');
    cout<<"\nThanks for being member of Pinnacle club!";
};

void PinClub::display(){
    temp = president;
    cout<<"\nMember's information is as follows: ";
    while(temp!=NULL){
        cout<<"\n"<<temp->roll<<" "<<temp->name;
        temp = temp->next;
    }
}

void PinClub::addpresident(){
    nnode = new node;
    nnode->next = NULL;
    cout<<"Value to president: Enter roll number: ";
    cin>>nnode->roll;
    cout<<"Enter Name";
    cin>>nnode->roll;
    
}

int main()
{
    PinClub P1;
    cout<<"\nWelcome to Pinnacle club! ";
    P1.create();
    P1.display();
    return 0;
}